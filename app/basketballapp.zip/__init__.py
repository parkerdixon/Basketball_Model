from .basketballapp import application
application.static_folder = 'static'
